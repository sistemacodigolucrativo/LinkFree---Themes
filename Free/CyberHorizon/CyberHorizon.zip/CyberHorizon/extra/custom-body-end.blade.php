<script>
window.__LS_THEME_CONFIG__ = {
  mode: 'digital-grid',
  accent: '#ff007f',
  secondary: '#8b5cf6',
  speed: 1.2,
  intensity: 75,
  opacity: 0.85
};
</script>
<script src="{{themeAsset('theme-effects.js')}}"></script>
