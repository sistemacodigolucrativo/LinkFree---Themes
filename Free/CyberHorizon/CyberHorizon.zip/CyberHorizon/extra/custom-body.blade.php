{{-- Background Canvas & Non-blocking Geometric Overlay (digital-grid / hexagons) --}}
<canvas class="background" id="ls-studio-canvas" aria-hidden="true"></canvas>
<div class="ls-geo-layer" aria-hidden="true" data-geometry="hexagons"><svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="ls-hex" width="60" height="52" patternUnits="userSpaceOnUse"><polygon points="30,2 56,16 56,40 30,50 4,40 4,16" fill="none" stroke="#ff007f" stroke-width="0.9"/></pattern></defs><rect width="100%" height="100%" fill="url(#ls-hex)"/></svg></div>
