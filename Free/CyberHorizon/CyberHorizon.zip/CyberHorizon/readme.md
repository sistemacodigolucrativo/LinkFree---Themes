# A LinkStack Theme
Grade digital perspectiva, chanfros futuristas, hexágonos geométricos e brilho magenta neon.

*	Theme Name: Cyber Horizon
*	Theme Version: 1.0
*	Theme Date: 2026-11-16
*	Theme Author: LinkStack Theme Studio
*	Theme Author URI: https://linkstack.org
*   Theme License: MIT
*   Built using Skeleton CSS (MIT) and LinkStack Futuristic Theme Studio.

### Installation (Plug and Play)
* Extract `themes/CyberHorizon/` into your LinkStack root `themes/` folder (or upload via LinkStack -> Themes -> Import).
* Includes config.php, skeleton-auto.css, brands.css, animations.css, share.button.css, preview.png, and extra/ assets.
