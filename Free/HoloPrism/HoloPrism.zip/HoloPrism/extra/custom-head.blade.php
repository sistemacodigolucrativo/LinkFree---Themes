{{-- LinkStack Futuristic Theme Studio: Holo Prism --}}
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
<style>
  .ls-geo-layer {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 1;
    overflow: hidden;
    opacity: 0.32;
    transform: scale(1);
  }
  
</style>
