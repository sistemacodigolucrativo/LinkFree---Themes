<script>
window.__LS_THEME_CONFIG__ = {
  mode: 'geometric-waves',
  accent: '#38bdf8',
  secondary: '#e879f9',
  speed: 1.1,
  intensity: 80,
  opacity: 0.9
};
</script>
<script src="{{themeAsset('theme-effects.js')}}"></script>
