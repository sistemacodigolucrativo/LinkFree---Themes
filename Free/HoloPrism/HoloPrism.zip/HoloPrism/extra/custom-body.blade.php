{{-- Background Canvas & Non-blocking Geometric Overlay (geometric-waves / holographic-shards) --}}
<canvas class="background" id="ls-studio-canvas" aria-hidden="true"></canvas>
<div class="ls-geo-layer" aria-hidden="true" data-geometry="holographic-shards"><svg width="100%" height="100%" viewBox="0 0 600 900" preserveAspectRatio="xMidYMid slice"><polygon points="40,80 180,20 130,210" fill="rgba(56, 189, 248, 0.14)" stroke="#38bdf8" stroke-width="0.8"/><polygon points="550,140 420,240 570,350" fill="rgba(232, 121, 249, 0.14)" stroke="#e879f9" stroke-width="0.8"/></svg></div>
