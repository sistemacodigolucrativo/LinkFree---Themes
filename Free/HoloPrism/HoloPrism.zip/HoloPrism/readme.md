# A LinkStack Theme
Ondas geométricas iridescentes, bordas holográficas animadas e entrada escalonada.

*	Theme Name: Holo Prism
*	Theme Version: 1.0
*	Theme Date: 2026-11-16
*	Theme Author: LinkStack Theme Studio
*	Theme Author URI: https://linkstack.org
*   Theme License: MIT
*   Built using Skeleton CSS (MIT) and LinkStack Futuristic Theme Studio.

### Installation (Plug and Play)
* Extract `themes/HoloPrism/` into your LinkStack root `themes/` folder (or upload via LinkStack -> Themes -> Import).
* Includes config.php, skeleton-auto.css, brands.css, animations.css, share.button.css, preview.png, and extra/ assets.
