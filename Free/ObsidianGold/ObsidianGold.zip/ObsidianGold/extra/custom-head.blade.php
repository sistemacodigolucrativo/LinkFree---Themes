{{-- LinkStack Futuristic Theme Studio: Obsidian Gold --}}
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
<style>
  .ls-geo-layer {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 1;
    overflow: hidden;
    opacity: 0.32;
    transform: scale(1);
  }
  body::before {
    content: "";
    position: fixed;
    inset: 0;
    background-image: url('{{themeAsset('bg-backdrop.jpg')}}');
    background-size: cover;
    background-position: center;
    opacity: 0.47;
    z-index: 0;
    pointer-events: none;
  }
</style>
