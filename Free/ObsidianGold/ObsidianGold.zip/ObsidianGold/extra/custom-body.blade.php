{{-- Background Canvas & Non-blocking Geometric Overlay (image-backdrop / tech-frames) --}}
<canvas class="background" id="ls-studio-canvas" aria-hidden="true"></canvas>
<div class="ls-geo-layer" aria-hidden="true" data-geometry="tech-frames"><div style="position:absolute;inset:16px;border:1px solid rgba(245, 158, 11, 0.3);pointer-events:none;"></div></div>
