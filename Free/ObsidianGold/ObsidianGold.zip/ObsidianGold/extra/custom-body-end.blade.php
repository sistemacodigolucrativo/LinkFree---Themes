<script>
window.__LS_THEME_CONFIG__ = {
  mode: 'image-backdrop',
  accent: '#f59e0b',
  secondary: '#fde047',
  speed: 0.8,
  intensity: 55,
  opacity: 0.85
};
</script>
<script src="{{themeAsset('theme-effects.js')}}"></script>
