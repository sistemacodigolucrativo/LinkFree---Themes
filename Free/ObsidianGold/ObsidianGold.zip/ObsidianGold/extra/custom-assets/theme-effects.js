/* LinkStack Futuristic Theme Studio — extra/custom-assets/theme-effects.js */
(function () {
  var cfg = window.__LS_THEME_CONFIG__ || {
    mode: 'image-backdrop',
    accent: '#f59e0b',
    secondary: '#fde047',
    speed: 0.8,
    intensity: 55,
    opacity: 0.85
  };
  var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var canvas = document.getElementById('ls-studio-canvas');
  if (!canvas || !canvas.getContext) return;
  var ctx = canvas.getContext('2d');
  var particles = [];

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  var count = Math.max(18, Math.round((cfg.intensity / 100) * 65));
  for (var i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.65 * cfg.speed,
      vy: (Math.random() - 0.5) * 0.65 * cfg.speed,
      r: 1.2 + Math.random() * 2.2
    });
  }

  var tick = 0;
  function drawFrame() {
    tick += 0.015 * cfg.speed;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.globalAlpha = cfg.opacity * 0.72;
    if (cfg.mode === 'digital-grid' || cfg.mode === 'tech-pattern') {
      ctx.strokeStyle = cfg.accent;
      ctx.lineWidth = 0.7;
      var step = cfg.mode === 'tech-pattern' ? 32 : 48;
      var offset = reducedMotion ? 0 : (tick * 24) % step;
      for (var x = 0; x < canvas.width; x += step) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
      }
      for (var y = offset; y < canvas.height; y += step) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
      }
    } else if (cfg.mode === 'geometric-waves') {
      for (var l = 0; l < 4; l++) {
        ctx.strokeStyle = l % 2 === 0 ? cfg.accent : cfg.secondary;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        for (var wx = 0; wx <= canvas.width; wx += 14) {
          var wy = canvas.height * 0.35 + l * 65 + Math.sin(wx * 0.014 + tick + l) * (18 + cfg.intensity * 0.22);
          if (wx === 0) ctx.moveTo(wx, wy); else ctx.lineTo(wx, wy);
        }
        ctx.stroke();
      }
    } else {
      for (var i = 0; i < particles.length; i++) {
        var p = particles[i];
        if (!reducedMotion) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
          if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
        }
        ctx.fillStyle = i % 2 === 0 ? cfg.accent : cfg.secondary;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    if (!reducedMotion) {
      requestAnimationFrame(drawFrame);
    }
  }
  drawFrame();
})();
